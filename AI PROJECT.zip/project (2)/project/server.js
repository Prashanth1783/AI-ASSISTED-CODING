const express = require("express");
const app = express();
const path = require("path");
const nodemailer = require("nodemailer");


app.use(express.json());
app.use(express.static("public"));


let savedTimers = [];

// Configure email service (using Gmail - you'll need to set environment variables)
const transporter = nodemailer.createTransport({
	service: "gmail",
	auth: {
		user: process.env.EMAIL_USER || "your-email@gmail.com",
		pass: process.env.EMAIL_PASS || "your-app-password"
	}
});

// Send email notification
app.post("/send-email", (req, res) => {
	const { email, title } = req.body;
	
	if (!email || !title) {
		return res.status(400).json({ error: "Email and title required" });
	}

	const mailOptions = {
		from: process.env.EMAIL_USER || "your-email@gmail.com",
		to: email,
		subject: `⏱️ Timer Completed: ${title}`,
		html: `
			<h2>Your Timer Has Completed!</h2>
			<p><strong>Timer Name:</strong> ${title}</p>
			<p><strong>Completed At:</strong> ${new Date().toLocaleString()}</p>
			<p>Your countdown timer has finished. Time to take action!</p>
		`
	};

	transporter.sendMail(mailOptions, (error, info) => {
		if (error) {
			console.error("Email error:", error);
			return res.status(500).json({ error: "Failed to send email" });
		}
		res.json({ success: true, message: "Email sent successfully" });
	});
});

// Send SMS notification (using Twilio - optional)
app.post("/send-sms", (req, res) => {
	const { phone, title } = req.body;
	
	if (!phone || !title) {
		return res.status(400).json({ error: "Phone and title required" });
	}

	// This is a placeholder - requires Twilio setup
	// For now, send success response
	console.log(`SMS would be sent to ${phone}: Timer "${title}" completed`);
	res.json({ success: true, message: "SMS notification sent (demo mode)" });
});


app.post("/save", (req, res) => {
	savedTimers.push(req.body);
	res.send("Timer saved on server!");
});


app.get("/timers", (req, res) => {
	res.json(savedTimers);
});


app.listen(5000, () => console.log("Server running on port 5000"));