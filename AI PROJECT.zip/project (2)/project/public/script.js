let timer;
let totalTime;

// Send email and SMS notifications
async function sendNotifications(title) {
    const email = document.getElementById('eventEmail').value;
    const phone = document.getElementById('eventPhone').value;

    if (email) {
        try {
            const res = await fetch('/send-email', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, title: title || 'Timer' })
            });
            const data = await res.json();
            if (data.success) console.log('Email sent:', email);
        } catch (e) {
            console.error('Email send failed:', e);
        }
    }

    if (phone) {
        try {
            const res = await fetch('/send-sms', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ phone, title: title || 'Timer' })
            });
            const data = await res.json();
            if (data.success) console.log('SMS sent:', phone);
        } catch (e) {
            console.error('SMS send failed:', e);
        }
    }
}

// Notify user when timer completes: desktop notification (permission requested if needed)
// and short audible beep as fallback/augment.
function notifyUser(title, body) {
    // Desktop notification
    try {
        if ("Notification" in window) {
            if (Notification.permission === 'granted') {
                new Notification(title, { body });
            } else if (Notification.permission !== 'denied') {
                Notification.requestPermission().then(permission => {
                    if (permission === 'granted') new Notification(title, { body });
                });
            }
        } else {
            // Fallback to alert when Notification API isn't available
            alert(title + (body ? '\n' + body : ''));
        }
    } catch (e) {
        try { alert(title + (body ? '\n' + body : '')); } catch (e) {}
    }

    // Short beep using Web Audio API
    try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        const ctx = new AudioCtx();
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'sine';
        o.frequency.value = 880;
        o.connect(g);
        g.connect(ctx.destination);
        g.gain.setValueAtTime(0.0001, ctx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.5, ctx.currentTime + 0.01);
        o.start();
        g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.7);
        o.stop(ctx.currentTime + 0.8);
    } catch (e) {}
}

function startTimer() {
    const eventInput = document.getElementById("eventTime").value;
    // Parse `datetime-local` value manually to avoid inconsistent Date parsing
    // expected format: "YYYY-MM-DDTHH:MM" (no timezone)
    let eventTime;
    if (eventInput && eventInput.includes('T')) {
        const [datePart, timePart] = eventInput.split('T');
        const [year, month, day] = datePart.split('-').map(Number);
        const [hour, minute] = timePart.split(':').map(Number);
        eventTime = new Date(year, month - 1, day, hour || 0, minute || 0, 0, 0);
    } else {
        eventTime = new Date(eventInput);
    }
    const now = new Date();

    // FIX: Proper check for empty or invalid date
    if (isNaN(eventTime.getTime())) {
        alert("Please select date and time.");
        return;
    }

    // require a future time (allow small ms differences). If remainingMs <= 0 it's in the past.
    const remainingMs = eventTime.getTime() - now.getTime();
    if (remainingMs <= 0) {
        alert("Select a valid future time.");
        return;
    }

    totalTime = remainingMs;

    timer = setInterval(() => {
        let remaining = eventTime - new Date();

        if (remaining <= 0) {
            clearInterval(timer);
            const eventName = document.getElementById('eventName').value || 'Timer Complete';
            document.getElementById("output").innerText = `🎉 ${eventName}!`;
            document.getElementById("output").style.animation = 'pulse 0.6s ease-in-out infinite';
            document.getElementById("bar").style.width = "100%";
            // notify user (use eventName if provided)
            const title = eventName;
            notifyUser(title, 'Your countdown has completed.');
            // Send email and SMS notifications
            sendNotifications(eventName);
            return;
        }

        // compute days, hours, minutes, seconds for a clear display
        let days = Math.floor(remaining / (1000 * 60 * 60 * 24));
        let h = Math.floor((remaining / (1000 * 60 * 60)) % 24);
        let m = Math.floor((remaining / (1000 * 60)) % 60);
        let s = Math.floor((remaining / 1000) % 60);

        let display = '';
        if (days > 0) display += `${days}d `;
        display += `${h}h ${m}m ${s}s`;
        document.getElementById("output").innerText = display;

        let progress = ((totalTime - remaining) / totalTime) * 100;
        document.getElementById("bar").style.width = progress + "%";
    }, 1000);
}

function resetTimer() {
    clearInterval(timer);
    document.getElementById("output").innerText = "Timer not started";
    document.getElementById("bar").style.width = "0%";
}

async function saveTimer() {
    const eventName = document.getElementById("eventName").value;
    const eventTime = document.getElementById("eventTime").value;

    const res = await fetch("/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ eventName, eventTime })
    });

    alert(await res.text());
}
