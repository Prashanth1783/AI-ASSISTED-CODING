let predictTimer = null;
let lastRemaining = 0;
let isPaused = false;

function formatSeconds(sec) {
	const days = Math.floor(sec / 86400);
	sec = sec % 86400;
	const hours = Math.floor(sec / 3600);
	sec = sec % 3600;
	const minutes = Math.floor(sec / 60);
	const seconds = sec % 60;
	let parts = [];
	if (days) parts.push(`${days}d`);
	parts.push(`${hours}h`);
	parts.push(`${minutes}m`);
	parts.push(`${seconds}s`);
	return parts.join(' ');
}

function predict() {
	// clear any existing countdown
	if (predictTimer) {
		clearInterval(predictTimer);
		predictTimer = null;
	}

	const value = parseFloat(document.getElementById("countdownValue").value);
	const unit = document.getElementById("countdownUnit").value;
	
	if (isNaN(value) || value <= 0) {
		document.getElementById("result").innerText = 'Please enter a positive number.';
		return;
	}

	// Convert to seconds based on selected unit
	let remaining = 0;
	if (unit === 'seconds') {
		remaining = Math.floor(value);
	} else if (unit === 'minutes') {
		remaining = Math.floor(value * 60);
	} else if (unit === 'hours') {
		remaining = Math.floor(value * 3600);
	}

	// initial display
	document.getElementById("result").innerText = `Remaining: ${formatSeconds(remaining)}`;
	lastRemaining = remaining;

	predictTimer = setInterval(() => {
		remaining -= 1;
		lastRemaining = remaining;
		if (remaining <= 0) {
			clearInterval(predictTimer);
			predictTimer = null;
			document.getElementById("result").innerText = '🎉 TIME UP!';
			// notify user: request permission if needed and play beep
			try {
				if ("Notification" in window) {
					if (Notification.permission === 'granted') {
						new Notification('Countdown finished', { body: 'The predicted countdown has completed.' });
					} else if (Notification.permission !== 'denied') {
						Notification.requestPermission().then(permission => {
							if (permission === 'granted') new Notification('Countdown finished', { body: 'The predicted countdown has completed.' });
						});
					}
				} else {
					alert('Countdown finished');
				}
			} catch (e) { try { alert('Countdown finished'); } catch (e) {} }
			// beep
			try {
				const AudioCtx = window.AudioContext || window.webkitAudioContext;
				const ctx = new AudioCtx();
				const o = ctx.createOscillator();
				const g = ctx.createGain();
				o.type = 'sawtooth';
				o.frequency.value = 880;
				o.connect(g);
				g.connect(ctx.destination);
				g.gain.setValueAtTime(0.0001, ctx.currentTime);
				g.gain.exponentialRampToValueAtTime(0.5, ctx.currentTime + 0.01);
				o.start();
				g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.7);
				o.stop(ctx.currentTime + 0.8);
			} catch (e) {}
			return;
		}
		document.getElementById("result").innerText = `Remaining: ${formatSeconds(remaining)}`;
	}, 1000);
}

function togglePause() {
	if (!predictTimer && !isPaused) return; // No countdown running
	
	if (isPaused) {
		// Resume
		isPaused = false;
		document.querySelector('button[onclick="togglePause()"]').textContent = '⏸ Pause';
		
		// Resume countdown
		predictTimer = setInterval(() => {
			lastRemaining -= 1;
			if (lastRemaining <= 0) {
				clearInterval(predictTimer);
				predictTimer = null;
				document.getElementById("result").innerText = '🎉 TIME UP!';
				return;
			}
			document.getElementById("result").innerText = `Remaining: ${formatSeconds(lastRemaining)}`;
		}, 1000);
	} else {
		// Pause
		isPaused = true;
		clearInterval(predictTimer);
		predictTimer = null;
		document.querySelector('button[onclick="togglePause()"]').textContent = '▶ Resume';
		const currentText = document.getElementById("result").innerText;
		if (!currentText.includes('(Paused)')) {
			document.getElementById("result").innerText = currentText + ' (Paused)';
		}
	}
}

function resetCountdown() {
	if (predictTimer) {
		clearInterval(predictTimer);
		predictTimer = null;
	}
	isPaused = false;
	lastRemaining = 0;
	document.countdownValue = '';
	document.getElementById("countdownValue").value = '';
	document.getElementById("countdownUnit").value = 'seconds';
	document.getElementById("result").innerText = '';
	document.querySelector('button[onclick="togglePause()"]').textContent = '⏸ Pause';
}